$(window).on("scroll", function() {
  if($(window).scrollTop()) {
    $('nav').addClass('black');
  } else {
    $('nav').removeClass('black');
  }
})

var modal = document.getElementById('modal-wrapper');
window.onclick = function(event) {
  if (event.target == modal) {
    modal.style.display = "none";
  }
}

function checkLogin() {
  var username = document.getElementById('usernameL').value;
  var password = document.getElementById('passwordL').value;
  if(username == '' || password == '') {
    window.alert("Fill in all the details properly!");
  }
}

function checkSignUp() {
  var name = document.getElementById('name').value;
  var username = document.getElementById('username').value;
  var email = document.getElementById('email').value;
  var city = document.getElementById('city').value;
  var password = document.getElementById('password').value;
  var reTypePassword = document.getElementById('reTypePassword').value;
  if(name == '' || username == '' || email == '' || city == '' || password == '' || reTypePassword == '') {
    window.alert("Please fill in all the details properly!");
  }
}

const carouselSlide = document.querySelector('.carousel-slide');
const carouselImages = document.querySelectorAll('.carousel-slide img');
//Buttons
const prevButton = document.querySelector('#prevButton');
const nextButton = document.querySelector('#nextButton');

//counter
let counter = 1;
const size = carouselImages[0].clientWidth;

carouselSlide.style.transform = 'translateX(' + (- size * counter) + 'px)';

//Button Listeners

nextButton.addEventListener('click',()=>{
  if (counter >= carouselImages.length-1) return;
  carouselSlide.style.transition = "transform 1s ease-in-out";
  counter++;
  carouselSlide.style.transform = 'translateX(' + (- size * counter) + 'px)';
});

prevButton.addEventListener('click',()=>{
  if (counter <= 0) return;
  carouselSlide.style.transition = "transform 1s ease-in-out";
  counter--;
  carouselSlide.style.transform = 'translateX(' + (- size * counter) + 'px)';
});

carouselSlide.addEventListener('transitionend', ()=>{
  if (carouselImages[counter].id === 'lastClone') {
    carouselSlide.style.transition = "none";
    counter = carouselImages.length-2;
    carouselSlide.style.transform = 'translateX(' + (- size * counter) + 'px)';
  }
  if (carouselImages[counter].id === 'firstClone') {
    carouselSlide.style.transition = "none";
    counter = carouselImages.length-counter;
    carouselSlide.style.transform = 'translateX(' + (- size * counter) + 'px)';
  }
});
